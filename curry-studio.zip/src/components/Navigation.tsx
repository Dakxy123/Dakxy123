import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const navItems = [
    { path: "/", label: "Home" },
    { path: "/about", label: "About" },
    { path: "/gallery", label: "Gallery" },
    { path: "/contact", label: "Contact" },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-space-dark-matter/80 backdrop-blur-md border-b border-space-cosmic-blue/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo/Brand */}
          <Link
            to="/"
            className="flex items-center space-x-2 group"
            onClick={() => setIsOpen(false)}
          >
            <div className="w-8 h-8 bg-gradient-to-r from-space-nebula-pink to-space-stellar-purple rounded-full flex items-center justify-center group-hover:animate-pulse-glow transition-all duration-300">
              <div className="w-4 h-4 bg-space-black rounded-full"></div>
            </div>
            <span className="text-xl font-bold glow-text-pink">JLV</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`px-3 py-2 text-sm font-medium transition-all duration-300 hover:glow-text-pink ${
                    isActive(item.path)
                      ? "text-space-nebula-pink glow-text-pink"
                      : "text-space-cosmic-silver hover:text-space-star-white"
                  }`}
                >
                  {item.label}
                </Link>
              ))}
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsOpen(!isOpen)}
              className="text-space-cosmic-silver hover:text-space-star-white hover:bg-space-cosmic-blue/30"
            >
              {isOpen ? <X size={20} /> : <Menu size={20} />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 bg-space-dark-matter/95 backdrop-blur-md rounded-lg mt-2 border border-space-cosmic-blue/30">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setIsOpen(false)}
                  className={`block px-3 py-2 text-base font-medium transition-all duration-300 rounded-md ${
                    isActive(item.path)
                      ? "text-space-nebula-pink glow-text-pink bg-space-cosmic-blue/20"
                      : "text-space-cosmic-silver hover:text-space-star-white hover:bg-space-cosmic-blue/20"
                  }`}
                >
                  {item.label}
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navigation;
