import { useEffect, useRef } from "react";

interface BlackHoleBackgroundProps {
  children?: React.ReactNode;
  className?: string;
}

const BlackHoleBackground = ({
  children,
  className = "",
}: BlackHoleBackgroundProps) => {
  const particlesRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Generate random particles
    if (particlesRef.current) {
      const container = particlesRef.current;
      const particleCount = 50;

      for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement("div");
        particle.className = "space-particle";
        particle.style.left = `${Math.random() * 100}%`;
        particle.style.top = `${Math.random() * 100}%`;
        particle.style.animationDelay = `${Math.random() * 6}s`;
        particle.style.animationDuration = `${4 + Math.random() * 4}s`;
        container.appendChild(particle);
      }
    }

    return () => {
      if (particlesRef.current) {
        particlesRef.current.innerHTML = "";
      }
    };
  }, []);

  return (
    <div
      className={`relative min-h-screen bg-space-gradient overflow-hidden ${className}`}
    >
      {/* Background gradient overlay */}
      <div className="absolute inset-0 bg-space-gradient"></div>

      {/* Animated particles */}
      <div
        ref={particlesRef}
        className="absolute inset-0 pointer-events-none"
      />

      {/* Central black hole effect */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="relative">
          {/* Black hole core */}
          <div className="w-32 h-32 bg-space-black rounded-full shadow-2xl relative">
            {/* Glowing center */}
            <div className="absolute inset-0 bg-gradient-to-r from-space-nebula-pink to-space-stellar-purple rounded-full opacity-20 animate-pulse-glow"></div>
          </div>

          {/* Orbiting rings */}
          <div className="black-hole-ring w-48 h-48 -top-8 -left-8"></div>
          <div className="black-hole-ring w-64 h-64 -top-16 -left-16"></div>
          <div className="black-hole-ring w-80 h-80 -top-24 -left-24"></div>
        </div>
      </div>

      {/* Nebula overlay effects */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gradient-to-r from-space-nebula-pink/20 to-transparent rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-gradient-to-r from-space-stellar-purple/20 to-transparent rounded-full blur-3xl"></div>
        <div className="absolute top-3/4 left-1/2 w-64 h-64 bg-gradient-to-r from-blue-500/20 to-transparent rounded-full blur-2xl"></div>
      </div>

      {/* Content */}
      <div className="relative z-10">{children}</div>
    </div>
  );
};

export default BlackHoleBackground;
