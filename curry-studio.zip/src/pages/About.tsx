import BlackHoleBackground from "@/components/BlackHoleBackground";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Code, Palette, Rocket, Users } from "lucide-react";

const About = () => {
  const skills = [
    "JavaScript",
    "TypeScript",
    "React",
    "Node.js",
    "Python",
    "PostgreSQL",
    "AWS",
    "Docker",
    "Git",
    "GraphQL",
    "Next.js",
    "TailwindCSS",
  ];

  const experiences = [
    {
      title: "Senior Full Stack Developer",
      company: "Tech Innovators Inc.",
      period: "2022 - Present",
      description:
        "Leading development of scalable web applications and mentoring junior developers.",
    },
    {
      title: "Frontend Developer",
      company: "Creative Solutions LLC",
      period: "2020 - 2022",
      description:
        "Specialized in React development and UI/UX implementation for client projects.",
    },
    {
      title: "Junior Developer",
      company: "StartUp Dynamics",
      period: "2018 - 2020",
      description:
        "Gained experience in full-stack development and agile methodologies.",
    },
  ];

  const values = [
    {
      icon: <Code className="w-8 h-8" />,
      title: "Clean Code",
      description:
        "Writing maintainable, scalable, and well-documented code that stands the test of time.",
    },
    {
      icon: <Palette className="w-8 h-8" />,
      title: "Design Thinking",
      description:
        "Combining technical expertise with creative problem-solving to build intuitive experiences.",
    },
    {
      icon: <Rocket className="w-8 h-8" />,
      title: "Innovation",
      description:
        "Staying ahead of technology trends and implementing cutting-edge solutions.",
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Collaboration",
      description:
        "Working effectively with teams to deliver exceptional results through communication.",
    },
  ];

  return (
    <BlackHoleBackground>
      <div className="pt-24 pb-16 px-4">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-16 animate-fade-in">
            <h1 className="text-4xl md:text-6xl font-bold glow-text mb-6">
              About <span className="glow-text-pink">Me</span>
            </h1>
            <p className="text-xl text-space-cosmic-silver max-w-3xl mx-auto leading-relaxed">
              Passionate developer with a love for creating innovative digital
              solutions that make a difference in people's lives.
            </p>
          </div>

          {/* Main Bio Section */}
          <div className="grid md:grid-cols-2 gap-8 mb-16">
            <Card className="bg-space-dark-matter/40 border-space-cosmic-blue/30 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-space-star-white text-2xl glow-text">
                  My Story
                </CardTitle>
              </CardHeader>
              <CardContent className="text-space-cosmic-silver space-y-4">
                <p>
                  Hello! I'm Jorge Louise C. Venerable, a full-stack developer
                  based in the digital cosmos. My journey into programming began
                  during my college years when I discovered the power of code to
                  transform ideas into reality.
                </p>
                <p>
                  With over 5 years of experience in web development, I've had
                  the privilege of working on diverse projects ranging from
                  small business websites to large-scale enterprise
                  applications. I specialize in modern JavaScript frameworks and
                  love exploring new technologies that push the boundaries of
                  what's possible on the web.
                </p>
                <p>
                  When I'm not coding, you can find me exploring the latest in
                  space technology, contributing to open-source projects, or
                  sharing knowledge with the developer community.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-space-dark-matter/40 border-space-cosmic-blue/30 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-space-star-white text-2xl glow-text">
                  Skills & Technologies
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {skills.map((skill) => (
                    <Badge
                      key={skill}
                      variant="outline"
                      className="bg-gradient-to-r from-space-stellar-purple/20 to-space-nebula-pink/20 border-space-cosmic-blue text-space-star-white hover:bg-space-cosmic-blue/30 transition-all duration-300"
                    >
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Core Values */}
          <div className="mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-center glow-text mb-12">
              Core <span className="glow-text-pink">Values</span>
            </h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {values.map((value, index) => (
                <Card
                  key={index}
                  className="bg-space-dark-matter/40 border-space-cosmic-blue/30 backdrop-blur-sm hover:bg-space-cosmic-blue/20 transition-all duration-300 group"
                >
                  <CardContent className="p-6 text-center">
                    <div className="text-space-nebula-pink mb-4 group-hover:scale-110 transition-transform duration-300 flex justify-center">
                      {value.icon}
                    </div>
                    <h3 className="text-space-star-white font-semibold mb-2">
                      {value.title}
                    </h3>
                    <p className="text-space-cosmic-silver text-sm">
                      {value.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Experience Timeline */}
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-center glow-text mb-12">
              Professional <span className="glow-text-pink">Journey</span>
            </h2>
            <div className="space-y-6">
              {experiences.map((exp, index) => (
                <Card
                  key={index}
                  className="bg-space-dark-matter/40 border-space-cosmic-blue/30 backdrop-blur-sm hover:bg-space-cosmic-blue/10 transition-all duration-300"
                >
                  <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-3">
                      <h3 className="text-xl font-semibold text-space-star-white glow-text">
                        {exp.title}
                      </h3>
                      <span className="text-space-nebula-pink font-medium">
                        {exp.period}
                      </span>
                    </div>
                    <p className="text-space-cosmic-silver font-medium mb-2">
                      {exp.company}
                    </p>
                    <p className="text-space-cosmic-silver">
                      {exp.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </BlackHoleBackground>
  );
};

export default About;
