import BlackHoleBackground from "@/components/BlackHoleBackground";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink, Github, Play } from "lucide-react";

const Gallery = () => {
  // Placeholder data - these would typically come from an API or CMS
  const projects = [
    {
      id: 1,
      title: "E-Commerce Platform",
      type: "Web Application",
      image: "/placeholder.svg",
      description:
        "Full-stack e-commerce solution built with React, Node.js, and PostgreSQL.",
      technologies: ["React", "Node.js", "PostgreSQL", "Stripe"],
      liveUrl: "#",
      githubUrl: "#",
    },
    {
      id: 2,
      title: "Portfolio Website",
      type: "Frontend",
      image: "/placeholder.svg",
      description:
        "Responsive portfolio website with dark theme and animations.",
      technologies: ["React", "TailwindCSS", "Framer Motion"],
      liveUrl: "#",
      githubUrl: "#",
    },
    {
      id: 3,
      title: "Task Management App",
      type: "Full Stack",
      image: "/placeholder.svg",
      description:
        "Collaborative task management application with real-time updates.",
      technologies: ["Next.js", "Socket.io", "MongoDB"],
      liveUrl: "#",
      githubUrl: "#",
    },
    {
      id: 4,
      title: "Weather Dashboard",
      type: "Frontend",
      image: "/placeholder.svg",
      description: "Beautiful weather dashboard with location-based forecasts.",
      technologies: ["Vue.js", "Chart.js", "Weather API"],
      liveUrl: "#",
      githubUrl: "#",
    },
    {
      id: 5,
      title: "Blog Platform",
      type: "Full Stack",
      image: "/placeholder.svg",
      description:
        "Content management system for bloggers with rich text editor.",
      technologies: ["React", "Express", "MongoDB", "AWS S3"],
      liveUrl: "#",
      githubUrl: "#",
    },
    {
      id: 6,
      title: "Mobile Banking App",
      type: "Mobile",
      image: "/placeholder.svg",
      description:
        "Secure mobile banking application with biometric authentication.",
      technologies: ["React Native", "Firebase", "Redux"],
      liveUrl: "#",
      githubUrl: "#",
    },
  ];

  const videos = [
    {
      id: 1,
      title: "App Demo - Task Manager",
      thumbnail: "/placeholder.svg",
      description:
        "Complete walkthrough of the task management application features.",
      videoUrl: "#",
    },
    {
      id: 2,
      title: "Code Review Session",
      thumbnail: "/placeholder.svg",
      description:
        "Live code review session showing best practices and optimization techniques.",
      videoUrl: "#",
    },
  ];

  return (
    <BlackHoleBackground>
      <div className="pt-24 pb-16 px-4">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="text-center mb-16 animate-fade-in">
            <h1 className="text-4xl md:text-6xl font-bold glow-text mb-6">
              Project <span className="glow-text-pink">Gallery</span>
            </h1>
            <p className="text-xl text-space-cosmic-silver max-w-3xl mx-auto leading-relaxed">
              A showcase of my technical projects, creative works, and
              development journey. Each piece represents a unique challenge and
              learning experience.
            </p>
          </div>

          {/* Projects Grid */}
          <div className="mb-16">
            <h2 className="text-3xl md:text-4xl font-bold glow-text mb-8">
              Featured <span className="glow-text-pink">Projects</span>
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects.map((project) => (
                <Card
                  key={project.id}
                  className="bg-space-dark-matter/40 border-space-cosmic-blue/30 backdrop-blur-sm hover:bg-space-cosmic-blue/10 transition-all duration-300 group"
                >
                  <div className="aspect-video bg-space-cosmic-blue/20 rounded-t-lg overflow-hidden">
                    <img
                      src={project.image}
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-xl font-semibold text-space-star-white glow-text">
                        {project.title}
                      </h3>
                      <Badge
                        variant="outline"
                        className="bg-space-nebula-pink/20 border-space-nebula-pink text-space-star-white"
                      >
                        {project.type}
                      </Badge>
                    </div>
                    <p className="text-space-cosmic-silver mb-4 text-sm">
                      {project.description}
                    </p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.technologies.map((tech) => (
                        <Badge
                          key={tech}
                          variant="outline"
                          className="bg-space-stellar-purple/20 border-space-cosmic-blue text-space-star-white text-xs"
                        >
                          {tech}
                        </Badge>
                      ))}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        className="bg-gradient-to-r from-space-nebula-pink to-space-stellar-purple hover:from-space-stellar-purple hover:to-space-nebula-pink flex-1"
                        asChild
                      >
                        <a
                          href={project.liveUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <ExternalLink size={16} className="mr-2" />
                          Live Demo
                        </a>
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-space-cosmic-blue bg-transparent text-space-star-white hover:bg-space-cosmic-blue/20"
                        asChild
                      >
                        <a
                          href={project.githubUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <Github size={16} />
                        </a>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Videos Section */}
          <div>
            <h2 className="text-3xl md:text-4xl font-bold glow-text mb-8">
              Demo <span className="glow-text-pink">Videos</span>
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              {videos.map((video) => (
                <Card
                  key={video.id}
                  className="bg-space-dark-matter/40 border-space-cosmic-blue/30 backdrop-blur-sm hover:bg-space-cosmic-blue/10 transition-all duration-300 group"
                >
                  <div className="aspect-video bg-space-cosmic-blue/20 rounded-t-lg overflow-hidden relative">
                    <img
                      src={video.thumbnail}
                      alt={video.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 flex items-center justify-center bg-black/30 group-hover:bg-black/20 transition-all duration-300">
                      <Button
                        size="lg"
                        className="bg-space-nebula-pink/90 hover:bg-space-nebula-pink text-space-star-white rounded-full w-16 h-16 p-0"
                        asChild
                      >
                        <a
                          href={video.videoUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <Play size={24} />
                        </a>
                      </Button>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <h3 className="text-xl font-semibold text-space-star-white glow-text mb-2">
                      {video.title}
                    </h3>
                    <p className="text-space-cosmic-silver text-sm">
                      {video.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </BlackHoleBackground>
  );
};

export default Gallery;
