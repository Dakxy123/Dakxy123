import BlackHoleBackground from "@/components/BlackHoleBackground";
import { Button } from "@/components/ui/button";
import { ArrowDown, Github, Linkedin, Mail } from "lucide-react";
import { Link } from "react-router-dom";

const Home = () => {
  return (
    <BlackHoleBackground>
      <div className="flex flex-col items-center justify-center min-h-screen px-4 pt-16">
        {/* Hero Section */}
        <div className="text-center space-y-6 animate-fade-in">
          {/* Main Title */}
          <h1 className="hero-title font-bold glow-text">
            Jorge Louise C.
            <span className="block glow-text-pink">Venerable</span>
          </h1>

          {/* Subtitle */}
          <p className="hero-subtitle text-space-cosmic-silver max-w-2xl mx-auto leading-relaxed">
            Full Stack Developer & Creative Technologist
            <span className="block mt-2 text-space-star-white/80">
              Crafting digital experiences that push the boundaries of
              possibility
            </span>
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mt-8">
            <Button
              asChild
              className="bg-gradient-to-r from-space-nebula-pink to-space-stellar-purple hover:from-space-stellar-purple hover:to-space-nebula-pink text-space-star-white border-0 px-8 py-3 text-lg font-semibold shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
            >
              <Link to="/about">Explore My Universe</Link>
            </Button>

            <Button
              asChild
              variant="outline"
              className="border-space-cosmic-blue bg-transparent text-space-star-white hover:bg-space-cosmic-blue/20 px-8 py-3 text-lg font-semibold transition-all duration-300 hover:scale-105"
            >
              <Link to="/contact">Get In Touch</Link>
            </Button>
          </div>

          {/* Social Links */}
          <div className="flex justify-center space-x-6 mt-12">
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-space-cosmic-silver hover:text-space-nebula-pink transition-all duration-300 hover:scale-110"
            >
              <Github size={24} />
            </a>
            <a
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-space-cosmic-silver hover:text-space-nebula-pink transition-all duration-300 hover:scale-110"
            >
              <Linkedin size={24} />
            </a>
            <a
              href="mailto:jorge@example.com"
              className="text-space-cosmic-silver hover:text-space-nebula-pink transition-all duration-300 hover:scale-110"
            >
              <Mail size={24} />
            </a>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <Link
            to="/about"
            className="text-space-cosmic-silver hover:text-space-nebula-pink transition-colors duration-300"
          >
            <ArrowDown size={24} />
          </Link>
        </div>
      </div>

      {/* Brief Introduction Section */}
      <div className="px-4 py-16">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-space-star-white mb-6 glow-text">
            Welcome to My Digital Cosmos
          </h2>
          <p className="text-lg md:text-xl text-space-cosmic-silver leading-relaxed max-w-3xl mx-auto">
            I'm a passionate developer who believes in creating meaningful
            digital experiences. With expertise spanning both frontend and
            backend development, I bring ideas to life through clean code,
            innovative design, and cutting-edge technology.
          </p>
        </div>
      </div>
    </BlackHoleBackground>
  );
};

export default Home;
