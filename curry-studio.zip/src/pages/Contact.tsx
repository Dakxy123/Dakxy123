import BlackHoleBackground from "@/components/BlackHoleBackground";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Mail, Phone, MapPin, Github, Linkedin, Twitter } from "lucide-react";

const Contact = () => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission here
    console.log("Form submitted");
  };

  const contactInfo = [
    {
      icon: <Mail className="w-6 h-6" />,
      label: "Email",
      value: "jorge@example.com",
      href: "mailto:jorge@example.com",
    },
    {
      icon: <Phone className="w-6 h-6" />,
      label: "Phone",
      value: "+1 (555) 123-4567",
      href: "tel:+15551234567",
    },
    {
      icon: <MapPin className="w-6 h-6" />,
      label: "Location",
      value: "San Francisco, CA",
      href: "#",
    },
  ];

  const socialLinks = [
    {
      icon: <Github className="w-6 h-6" />,
      label: "GitHub",
      href: "https://github.com",
      username: "@jorgevenerable",
    },
    {
      icon: <Linkedin className="w-6 h-6" />,
      label: "LinkedIn",
      href: "https://linkedin.com",
      username: "Jorge Louise C. Venerable",
    },
    {
      icon: <Twitter className="w-6 h-6" />,
      label: "Twitter",
      href: "https://twitter.com",
      username: "@jorge_dev",
    },
  ];

  return (
    <BlackHoleBackground>
      <div className="pt-24 pb-16 px-4">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-16 animate-fade-in">
            <h1 className="text-4xl md:text-6xl font-bold glow-text mb-6">
              Get In <span className="glow-text-pink">Touch</span>
            </h1>
            <p className="text-xl text-space-cosmic-silver max-w-3xl mx-auto leading-relaxed">
              Ready to collaborate on your next project? Let's connect and
              discuss how we can bring your ideas to life in the digital
              universe.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <Card className="bg-space-dark-matter/40 border-space-cosmic-blue/30 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-space-star-white text-2xl glow-text">
                  Send a Message
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label
                        htmlFor="firstName"
                        className="text-space-star-white"
                      >
                        First Name
                      </Label>
                      <Input
                        id="firstName"
                        type="text"
                        required
                        className="bg-space-cosmic-blue/20 border-space-cosmic-blue text-space-star-white placeholder:text-space-cosmic-silver focus:border-space-nebula-pink"
                        placeholder="John"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label
                        htmlFor="lastName"
                        className="text-space-star-white"
                      >
                        Last Name
                      </Label>
                      <Input
                        id="lastName"
                        type="text"
                        required
                        className="bg-space-cosmic-blue/20 border-space-cosmic-blue text-space-star-white placeholder:text-space-cosmic-silver focus:border-space-nebula-pink"
                        placeholder="Doe"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-space-star-white">
                      Email
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      required
                      className="bg-space-cosmic-blue/20 border-space-cosmic-blue text-space-star-white placeholder:text-space-cosmic-silver focus:border-space-nebula-pink"
                      placeholder="john@example.com"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="subject" className="text-space-star-white">
                      Subject
                    </Label>
                    <Input
                      id="subject"
                      type="text"
                      required
                      className="bg-space-cosmic-blue/20 border-space-cosmic-blue text-space-star-white placeholder:text-space-cosmic-silver focus:border-space-nebula-pink"
                      placeholder="Project Discussion"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message" className="text-space-star-white">
                      Message
                    </Label>
                    <Textarea
                      id="message"
                      required
                      rows={6}
                      className="bg-space-cosmic-blue/20 border-space-cosmic-blue text-space-star-white placeholder:text-space-cosmic-silver focus:border-space-nebula-pink resize-none"
                      placeholder="Tell me about your project..."
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-space-nebula-pink to-space-stellar-purple hover:from-space-stellar-purple hover:to-space-nebula-pink text-space-star-white font-semibold py-3 transition-all duration-300 hover:scale-105"
                  >
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Contact Information */}
            <div className="space-y-8">
              {/* Direct Contact */}
              <Card className="bg-space-dark-matter/40 border-space-cosmic-blue/30 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-space-star-white text-2xl glow-text">
                    Contact Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {contactInfo.map((item, index) => (
                    <a
                      key={index}
                      href={item.href}
                      className="flex items-center space-x-4 p-4 rounded-lg bg-space-cosmic-blue/10 hover:bg-space-cosmic-blue/20 transition-all duration-300 group"
                    >
                      <div className="text-space-nebula-pink group-hover:scale-110 transition-transform duration-300">
                        {item.icon}
                      </div>
                      <div>
                        <p className="text-space-cosmic-silver text-sm">
                          {item.label}
                        </p>
                        <p className="text-space-star-white font-medium">
                          {item.value}
                        </p>
                      </div>
                    </a>
                  ))}
                </CardContent>
              </Card>

              {/* Social Media */}
              <Card className="bg-space-dark-matter/40 border-space-cosmic-blue/30 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-space-star-white text-2xl glow-text">
                    Connect Online
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {socialLinks.map((social, index) => (
                    <a
                      key={index}
                      href={social.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center space-x-4 p-4 rounded-lg bg-space-cosmic-blue/10 hover:bg-space-cosmic-blue/20 transition-all duration-300 group"
                    >
                      <div className="text-space-nebula-pink group-hover:scale-110 transition-transform duration-300">
                        {social.icon}
                      </div>
                      <div>
                        <p className="text-space-cosmic-silver text-sm">
                          {social.label}
                        </p>
                        <p className="text-space-star-white font-medium">
                          {social.username}
                        </p>
                      </div>
                    </a>
                  ))}
                </CardContent>
              </Card>

              {/* Availability */}
              <Card className="bg-space-dark-matter/40 border-space-cosmic-blue/30 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-space-star-white text-2xl glow-text">
                    Availability
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-space-cosmic-silver">
                        Current Status
                      </span>
                      <span className="text-green-400 font-medium flex items-center">
                        <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></div>
                        Available for Projects
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-space-cosmic-silver">
                        Response Time
                      </span>
                      <span className="text-space-star-white font-medium">
                        Within 24 hours
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-space-cosmic-silver">
                        Time Zone
                      </span>
                      <span className="text-space-star-white font-medium">
                        PST (UTC-8)
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </BlackHoleBackground>
  );
};

export default Contact;
