function Yes() {
  let fortext = document.getElementById('fortext');
  fortext.innerHTML = "muah💋";
  let kisses = document.getElementById('kiss');
  kisses.src = '/peach-goma-love-smooch-kiss.gif'; 
  kisses.alt = 'kissesGIF';
  kisses.style.borderRadius = '50%';
}

let noButtonClickCount = 0;

function No() {
  let sizeofYes = document.getElementById('yes');
  let currentSize = parseInt(getComputedStyle(sizeofYes).fontSize);
  sizeofYes.style.fontSize = (currentSize + 10) + 'px';

  let sizeofNo = document.getElementById('no');
  
  noButtonClickCount++;

  if (noButtonClickCount >= 5) {
    sizeofNo.style.display = 'none';
  }
}
