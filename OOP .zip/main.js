document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("submit");
  const inputs = document.querySelectorAll(".inputbox input");

  inputs.forEach(input => {
    input.addEventListener("focus", () => {
      input.parentElement.classList.add("active");
    });

    input.addEventListener("blur", () => {
      if (input.value.trim() === "") {
        input.parentElement.classList.remove("active");
      }
    });
  });

  form.addEventListener("submit", e => {
    e.preventDefault();
    const tbody = document.querySelector(".table-container tbody");
    const row = document.createElement("tr");
    inputs.forEach(input => {
      const cell = document.createElement("td");
      cell.textContent = input.value;
      row.appendChild(cell);
    });
    const actionCell = document.createElement("td");
    const deleteButton = document.createElement("button");
    deleteButton.textContent = "Delete";
    deleteButton.style.backgroundColor = "#ff4d4d";
    deleteButton.style.border = "none";
    deleteButton.style.color = "white";
    deleteButton.style.padding = "5px 10px";
    deleteButton.style.cursor = "pointer";
    deleteButton.addEventListener("click", () => row.remove());
    actionCell.appendChild(deleteButton);
    row.appendChild(actionCell);
    tbody.appendChild(row);
    inputs.forEach(input => (input.value = ""));
    inputs[0].focus();
  });
});

document.addEventListener("click", (event) => {
    if (event.target.classList.contains("delete-btn")) {
        const id = event.target.dataset.id;

        fetch("delete.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ id }),
        })
            .then((response) => response.json())
            .then((data) => {
                if (data.success) {
                    alert("Product deleted successfully!");
                    event.target.closest("tr").remove();
                } else {
                    alert("Failed to delete product.");
                }
            });
    }
});

document.addEventListener("click", (event) => {
    if (event.target.classList.contains("edit-btn")) {
        const id = event.target.dataset.id;
        window.location.href = `edit.php?id=${id}`;
    }
});
