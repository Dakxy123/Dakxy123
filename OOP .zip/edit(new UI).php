<?php
include('db.php');

if (!isset($_GET['id'])) {
    die("Invalid request");
}

$id = $_GET['id'];
$sql = "SELECT * FROM products WHERE id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) {
    die("Product not found");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
</head>
<body>
    <div class="container">
        <h1>Edit Product</h1>
        <form action="update.php" method="POST">
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($product['id']); ?>">
            <input type="text" name="product_name" value="<?php echo htmlspecialchars($product['product_name']); ?>" required>
            <input type="text" name="category" value="<?php echo htmlspecialchars($product['category']); ?>" required>
            <input type="number" name="quantity" value="<?php echo htmlspecialchars($product['quantity']); ?>" required>
            <input type="number" name="price" value="<?php echo htmlspecialchars($product['price']); ?>" step="0.01" required>
            <input type="text" name="supplier" value="<?php echo htmlspecialchars($product['supplier']); ?>" required>
            <button type="submit">Update</button>
        </form>
    </div>
</body>
</html>
