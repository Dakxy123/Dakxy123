const infixinputValidator = document.getElementById('infixInput');
infixInput.addEventListener('input', event => {
  const inputValue = event.data;
  if (!/^[+\-*/^()\d\s]$/.test(inputValue)) {
    infixInput.value = infixInput.value.slice(0, -1);
  }
});
const isOperator = char => /[+\-*/^]/.test(char);
const isOperand = char => /[a-zA-Z0-9]/.test(char) || char === '.';
const getPrecedence = operator => {
  switch (operator) {
    case '+':
    case '-':
      return 1;
    case '*':
    case '/':
      return 2;
    case '^':
      return 3;
    default:
      return 0;
  }
};
const reverseExpression = expression => expression.split('').reverse().join('');
const validateExpression = expression => {
  if (!expression.trim()) {
    throw new Error("Please enter an expression.");
  }
};
const validateParentheses = expression => {
  let stack = [];
  for (let char of expression) {
    if (char === '(') {
      stack.push(char);
    } else if (char === ')') {
      if (stack.length === 0) {
        throw new Error("Mismatched parentheses: ')' without corresponding '('.");
      }
      stack.pop();
    }
  }
  if (stack.length > 0) {
    throw new Error("Mismatched parentheses: '(' without corresponding ')'.");
  }
};
const validateExpressionCharacters = expression => {
  const validCharacters = /[+\-*/^()\d\s]/;
  for (let char of expression) {
    if (!validCharacters.test(char)) {
      throw new Error(`Invalid character '${char}' in expression.`);
    }
  }
};

const displayStep = (stepNumber, output, operatorStack, inputExpression, type) => {
  let stepContainer;
  if (type === 'Postfix') {
    stepContainer = document.getElementById('postfixStepsContainer');
  } else if (type === 'Prefix') {
    stepContainer = document.getElementById('prefixStepsContainer');
  } else {
    console.error('Invalid step type');
    return;
  }
  const stepDiv = document.createElement('div');
  stepDiv.classList.add('step');
  stepDiv.innerHTML = `
    <table>
      <tr>
        <th colspan="3">Step ${stepNumber} (${type}):</th>
      </tr>
      <tr>
        <td>Output:</td>
        <td>${output}</td>
      </tr>
      <tr>
        <td>Operator Stack:</td>
        <td>${operatorStack}</td>
      </tr>
      <tr>
        <td>Input:</td>
        <td>${inputExpression}</td>
      </tr>
    </table>
  `;
  setTimeout(() => {
    stepContainer.appendChild(stepDiv);
  }, 1000 * stepNumber);
};

const animateOutput = (outputElement, text, buttonType) => {
  if (outputElement) {
    let index = 0;
    const interval = setInterval(() => {
      outputElement.innerText += text[index];
      index++;
      if (index >= text.length) {
        clearInterval(interval);
        if (buttonType === 'both') {
          document.getElementById('both').disabled = false;
          document.getElementById('prefix').disabled = false;
          document.getElementById('postfix').disabled = false;
        } else if (buttonType === 'postfix') {
          document.getElementById('postfix').disabled = false;
        } else if (buttonType === 'prefix') {
          document.getElementById('prefix').disabled = false;
        }
      }
    }, 1000);
  } else {
    console.error("Output element is not defined.");
  }
};

const infixToPostfix = expression => {
  let output = '';
  let operatorStack = [];
  let stepNumber = 1;
  try {
    validateExpression(expression);
    validateExpressionCharacters(expression);
    validateParentheses(expression);
    for (let i = 0; i < expression.length; i++) {
      let token = expression[i];
      if (isOperand(token)) {
        output += token;
      } else if (token === '(') {
        operatorStack.push(token);
      } else if (token === ')') {
        while (operatorStack.length && operatorStack[operatorStack.length - 1] !== '(') {
          output += operatorStack.pop();
        }
        operatorStack.pop();
      } else if (isOperator(token)) {
        while (operatorStack.length && getPrecedence(operatorStack[operatorStack.length - 1]) >= getPrecedence(token)) {
          output += operatorStack.pop();
        }
        operatorStack.push(token);
      }
      displayStep(stepNumber, output, operatorStack.join(' '), expression.substring(i), 'Postfix');
      stepNumber++;
    }
    while (operatorStack.length) {
      output += operatorStack.pop();
      displayStep(stepNumber, output, operatorStack.join(' '), '', 'Postfix');
      stepNumber++;
    }
  } catch (error) {
    document.getElementById('postfix').disabled = false;
    return alert("Error: " + error.message);
  }
  return output;
};

const infixToPrefix = expression => {
  let output = '';
  let operatorStack = [];
  let stepNumber = 1;
  try {
    validateExpression(expression);
    validateExpressionCharacters(expression);
    validateParentheses(expression);
    expression = reverseExpression(expression);
    for (let i = 0; i < expression.length; i++) {
      let token = expression[i];
      if (isOperand(token)) {
        output += token;
      } else if (token === ')') {
        operatorStack.push(token);
      } else if (token === '(') {
        while (operatorStack.length && operatorStack[operatorStack.length - 1] !== ')') {
          output += operatorStack.pop();
        }
        operatorStack.pop();
      } else if (isOperator(token)) {
        while (operatorStack.length && getPrecedence(operatorStack[operatorStack.length - 1]) > getPrecedence(token)) {
          output += operatorStack.pop();
        }
        operatorStack.push(token);
      }
      displayStep(stepNumber, reverseExpression(output), operatorStack.slice().reverse().join(' '), reverseExpression(expression.substring(i)), 'Prefix');
      stepNumber++;
    }
    while (operatorStack.length) {
      output += operatorStack.pop();
      displayStep(stepNumber, reverseExpression(output), operatorStack.slice().reverse().join(' '), '', 'Prefix');
      stepNumber++;
    }
  } catch (error) {
    document.getElementById('prefix').disabled = false;
    return alert("Error: " + error.message);
  }
  return reverseExpression(output);
};

const convertToPostfix = () => {
  refreshScreen();
  let infixExpression = document.getElementById('infixInput').value.trim();
  let postfixOutput = document.getElementById('postfixOutput');
  postfixOutput.innerText = ""; 
  let button = document.getElementById('postfix');
  button.disabled = true;
  if (infixExpression) {
    let postfix = infixToPostfix(infixExpression);
    animateOutput(postfixOutput, postfix, 'postfix');
  } else {
    alert("Please enter an expression before converting to postfix.");
    button.disabled = false;
  }
};

const covertBoth = () => {
  refreshScreen();
  convertToPrefix();
  convertToPostfix();
  let button = document.getElementById('both');
  button.disabled = true;
};

const convertToPrefix = () => {
  refreshScreen();
  let infixExpression = document.getElementById('infixInput').value.trim();
  let prefixOutput = document.getElementById('prefixOutput');
  prefixOutput.innerText = ""; 
  let button = document.getElementById('prefix');
  button.disabled = true;
  if (infixExpression) {
    let prefix = infixToPrefix(infixExpression);
    animateOutput(prefixOutput, prefix, 'prefix');
  } else {
    alert("Please enter an expression before converting to prefix.");
    button.disabled = false;
  }
};

const refreshScreen = () => {
  document.getElementById('postfixStepsContainer').innerHTML = '';
  document.getElementById('prefixStepsContainer').innerHTML = '';
};

document.getElementById('refreshButton').addEventListener('click', refreshScreen);