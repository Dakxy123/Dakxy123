document.addEventListener('DOMContentLoaded', () => {
    const infixInput = document.getElementById('infixInput');
    infixInput.addEventListener('input', event => {
        const inputValue = event.data;
        if (!/^[+\-*/^()\d\s]$/.test(inputValue)) {
            infixInput.value = infixInput.value.slice(0, -1);
        }
    });
});

const isOperator = char => /[+\-*/^]/.test(char);
const isOperand = char => /[a-zA-Z0-9]/.test(char) || char === '.';
const getPrecedence = operator => {
    switch (operator) {
        case '+':
        case '-':
            return 1;
        case '*':
        case '/':
            return 2;
        case '^':
            return 3;
        default:
            return 0;
    }
};
const reverseExpression = expression => expression.split('').reverse().join('');
const validateExpression = expression => {
    if (!expression.trim()) {
        throw new Error("Please enter an expression.");
    }
};
const validateParentheses = expression => {
    let stack = [];
    for (let char of expression) {
        if (char === '(') {
            stack.push(char);
        } else if (char === ')') {
            if (stack.length === 0) {
                throw new Error("Mismatched parentheses: ')' without corresponding '('.");
            }
            stack.pop();
        }
    }
    if (stack.length > 0) {
        throw new Error("Mismatched parentheses: '(' without corresponding ')'.");
    }
};
const validateExpressionCharacters = expression => {
    const validCharacters = /^[+\-*/^()\d\s]+$/;
    if (!validCharacters.test(expression)) {
        throw new Error("Invalid characters in expression.");
    }
};

const displayStep = (stepNumber, output, operatorStack, inputExpression, type) => {
    const stepsContainer = document.getElementById(`${type.toLowerCase()}StepsContainer`);
    const stepDiv = document.createElement('div');
    stepDiv.classList.add('step');
    stepDiv.innerHTML = `
        <table>
            <tr>
                <th colspan="3">Step ${stepNumber} (${type}):</th>
            </tr>
            <tr>
                <td>Output:</td>
                <td>${output}</td>
            </tr>
            <tr>
                <td>Operator Stack:</td>
                <td>${operatorStack}</td>
            </tr>
            <tr>
                <td>Input:</td>
                <td>${inputExpression}</td>
            </tr>
        </table>
    `;
    setTimeout(() => {
        stepsContainer.appendChild(stepDiv);
    }, 1000 * stepNumber);
};

const infixToPostfix = expression => {
    let output = '';
    let operatorStack = [];
    let stepNumber = 1;
    try {
        validateExpression(expression);
        validateExpressionCharacters(expression);
        validateParentheses(expression);
        for (let i = 0; i < expression.length; i++) {
            let token = expression[i];
            if (isOperand(token)) {
                output += token;
            } else if (token === '(') {
                operatorStack.push(token);
            } else if (token === ')') {
                while (operatorStack.length && operatorStack[operatorStack.length - 1] !== '(') {
                    output += operatorStack.pop();
                }
                operatorStack.pop();
            } else if (isOperator(token)) {
                while (operatorStack.length && getPrecedence(operatorStack[operatorStack.length - 1]) >= getPrecedence(token)) {
                    output += operatorStack.pop();
                }
                operatorStack.push(token);
            }
            displayStep(stepNumber, output, operatorStack.join(' '), expression.substring(i + 1), 'Postfix');
            stepNumber++;
        }
        while (operatorStack.length) {
            output += operatorStack.pop();
            displayStep(stepNumber, output, operatorStack.join(' '), '', 'Postfix');
            stepNumber++;
        }
    } catch (error) {
        alert("Error: " + error.message);
        setButtonState(true);
    }
    return output;
};

const infixToPrefix = expression => {
    let output = '';
    let operatorStack = [];
    let stepNumber = 1;
    try {
        validateExpression(expression);
        validateExpressionCharacters(expression);
        validateParentheses(expression);
        expression = reverseExpression(expression);
        for (let i = 0; i < expression.length; i++) {
            let token = expression[i];
            if (isOperand(token)) {
                output += token;
            } else if (token === ')') {
                operatorStack.push(token);
            } else if (token === '(') {
                while (operatorStack.length && operatorStack[operatorStack.length - 1] !== ')') {
                    output += operatorStack.pop();
                }
                operatorStack.pop();
            } else if (isOperator(token)) {
                while (operatorStack.length && getPrecedence(operatorStack[operatorStack.length - 1]) > getPrecedence(token)) {
                    output += operatorStack.pop();
                }
                operatorStack.push(token);
            }
            displayStep(stepNumber, reverseExpression(output), operatorStack.slice().reverse().join(' '), reverseExpression(expression.substring(i + 1)), 'Prefix');
            stepNumber++;
        }
        while (operatorStack.length) {
            output += operatorStack.pop();
            displayStep(stepNumber, reverseExpression(output), operatorStack.slice().reverse().join(' '), '', 'Prefix');
            stepNumber++;
        }
    } catch (error) {
        alert("Error: " + error.message);
        setButtonState(true);
    }
    return reverseExpression(output);
};

const convertToPostfix = () => {
    refreshScreen();
    let infixExpression = document.getElementById('infixInput').value.trim();
    let postfixOutput = document.getElementById('postfixOutput');
    postfixOutput.innerText = "";
    setButtonState(false);
    if (infixExpression) {
        let postfix = infixToPostfix(infixExpression);
        animateOutput(postfixOutput, postfix, 'postfix');
        const parseTreeRoot = buildParseTreeFromInfix(infixExpression);
        visualizeParseTree(parseTreeRoot);
        drawBinaryTree(postfix);
    } else {
        alert("Please enter an expression before converting to postfix.");
        setButtonState(true);
    }
};

const convertToPrefix = () => {
    refreshScreen();
    let infixExpression = document.getElementById('infixInput').value.trim();
    let prefixOutput = document.getElementById('prefixOutput');
    prefixOutput.innerText = "";
    setButtonState(false);
    if (infixExpression) {
        let prefix = infixToPrefix(infixExpression);
        animateOutput(prefixOutput, prefix, 'prefix');
        const parseTreeRoot = buildParseTreeFromInfix(infixExpression);
        visualizeParseTree(parseTreeRoot);
        drawBinaryTree(prefix);
    } else {
        alert("Please enter an expression before converting to prefix.");
        setButtonState(true);
    }
};

const convertBoth = () => {
    refreshScreen();
    let infixExpression = document.getElementById('infixInput').value.trim();
    let postfixOutput = document.getElementById('postfixOutput');
    let prefixOutput = document.getElementById('prefixOutput');
    postfixOutput.innerText = "";
    prefixOutput.innerText = "";
    setButtonState(false);
    if (infixExpression) {
        let postfix = infixToPostfix(infixExpression);
        let prefix = infixToPrefix(infixExpression);
        animateOutput(postfixOutput, postfix, 'postfix');
        animateOutput(prefixOutput, prefix, 'prefix');
        const parseTreeRoot = buildParseTreeFromInfix(infixExpression);
        visualizeParseTree(parseTreeRoot);
        drawBinaryTree(postfix);
    } else {
        alert("Please enter an expression before converting to postfix and prefix.");
        setButtonState(true);
    }
};

const animateOutput = (element, text, type) => {
    let index = 0;
    const interval = setInterval(() => {
        if (index < text.length) {
            element.innerText += text[index];
            index++;
        } else {
            clearInterval(interval);
            if (type !== 'both') {
                setButtonState(true);
            }
        }
    }, 500);
};

const setButtonState = state => {
    document.getElementById('postfix').disabled = !state;
    document.getElementById('prefix').disabled = !state;
    document.getElementById('both').disabled = !state;
};

const refreshScreen = () => {
    const stepContainers = document.querySelectorAll('.step-container');
    stepContainers.forEach(container => container.innerHTML = '');
    document.getElementById('postfixOutput').innerText = '';
    document.getElementById('prefixOutput').innerText = '';
};

const buildParseTreeFromInfix = infixExpression => {
    const postfix = infixToPostfix(infixExpression);
    const stack = [];
    for (let char of postfix) {
        if (isOperand(char)) {
            stack.push({ value: char, left: null, right: null });
        } else if (isOperator(char)) {
            const right = stack.pop();
            const left = stack.pop();
            stack.push({ value: char, left, right });
        }
    }
    return stack.pop();
};

const visualizeParseTree = root => {
    const container = document.getElementById('parseTreeContainer');
    container.innerHTML = '<canvas id="treeCanvas"></canvas>';
    const canvas = document.getElementById('treeCanvas');
    const ctx = canvas.getContext('2d');
    canvas.width = container.offsetWidth;
    canvas.height = 400;

    const nodeRadius = 20;
    const horizontalSpacing = 50;
    const verticalSpacing = 50;

    const drawNode = (node, x, y, parentX, parentY) => {
        if (!node) return;
        ctx.beginPath();
        ctx.arc(x, y, nodeRadius, 0, 2 * Math.PI);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = 'white';
        ctx.font = '12px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(node.value, x, y);
        ctx.fillStyle = 'black';
        if (parentX !== null && parentY !== null) {
            ctx.beginPath();
            ctx.moveTo(parentX, parentY);
            ctx.lineTo(x, y);
            ctx.stroke();
        }
        drawNode(node.left, x - horizontalSpacing, y + verticalSpacing, x, y);
        drawNode(node.right, x + horizontalSpacing, y + verticalSpacing, x, y);
    };

    if (root) {
        drawNode(root, canvas.width / 2, nodeRadius + 10, null, null);
    }
};

const drawBinaryTree = expression => {
    const binaryTreeContainer = document.getElementById('tree-container');
    binaryTreeContainer.innerHTML = '';
    const root = buildParseTreeFromInfix(expression);
    if (root) {
        const treeContainer = document.createElement('div');
        treeContainer.classList.add('tree-container');
        renderTreeNode(root, treeContainer);
        binaryTreeContainer.appendChild(treeContainer);
    }
};

const renderTreeNode = (node, container) => {
    const nodeElement = document.createElement('div');
    nodeElement.classList.add('tree-node');
    nodeElement.textContent = node.value;
    container.appendChild(nodeElement);
    const childrenContainer = document.createElement('div');
    childrenContainer.classList.add('tree-children');
    if (node.left) {
        renderTreeNode(node.left, childrenContainer);
    }
    if (node.right) {
        renderTreeNode(node.right, childrenContainer);
    }
    container.appendChild(childrenContainer);
};

const traverseTree = order => {
    const traversalOutput = document.getElementById('treeTraversalOutput');
    traversalOutput.innerText = '';
    const infixExpression = document.getElementById('infixInput').value.trim();
    const root = buildParseTreeFromInfix(infixExpression);
    let result = '';
    if (order === 'preorder') {
        result = preorderTraversal(root);
    } else if (order === 'inorder') {
        result = inorderTraversal(root);
    } else if (order === 'postorder') {
        result = postorderTraversal(root);
    }
    animateOutput(traversalOutput, result, order);
};

const preorderTraversal = node => {
    if (!node) return '';
    return node.value + preorderTraversal(node.left) + preorderTraversal(node.right);
};

const inorderTraversal = node => {
    if (!node) return '';
    return inorderTraversal(node.left) + node.value + inorderTraversal(node.right);
};

const postorderTraversal = node => {
    if (!node) return '';
    return postorderTraversal(node.left) + postorderTraversal(node.right) + node.value;
};
